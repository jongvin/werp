using System;
using System.Drawing;
using System.Windows.Forms;
namespace IEConvPage
{

	public class DirectoryNode : System.Windows.Forms.TreeNode 
	{ 
        
		public bool SubDirectoriesAdded;

		public DirectoryNode(String text) : base(text) 
		{

		}
	}



}