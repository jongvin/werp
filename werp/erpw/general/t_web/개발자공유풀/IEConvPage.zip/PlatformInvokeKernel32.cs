using System;
using System.Runtime.InteropServices;

namespace IEConvPage
{
	/// <summary>
	///    Summary description for PlatformInvokeKernel32.
	/// </summary>
	// <doc>
	// <desc>
	//        Declare native function to determine drive type
	// </desc>
	// </doc>
	//
	public class PlatformInvokeKernel32 
	{   
		[DllImport("KERNEL32", CharSet=System.Runtime.InteropServices.CharSet.Auto)]
		public static extern int GetDriveType(string lpRootPathName);  

		public const int DRIVE_FIXED = 3;
	}
}