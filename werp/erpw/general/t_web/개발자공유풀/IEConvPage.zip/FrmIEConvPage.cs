using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Win32;
using System.IO;

namespace IEConvPage
{
	/// <summary>
	/// FrmIEConvPage�� ���� ��� �����Դϴ�.
	/// </summary>
	public class FrmIEConvPage : System.Windows.Forms.Form
	{
		private static	string	RegHome = "IE_CONVPAGE";
		private	static	string	CLSID_SUBKEY = "CLSIDS";
		private	Hashtable				htFindWhat;
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Panel pnlFill;
		private System.Windows.Forms.Button btnConv;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ListBox lbxIDS;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnRemoveCLSID;
		private System.Windows.Forms.TextBox txtCLSID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnRemoveResult;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TreeView directoryTree;
		private System.Windows.Forms.Splitter splitter2;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.ListBox lbxFiles;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtFilter;
		private System.Windows.Forms.CheckBox chkAll;
		private System.Windows.Forms.Label lblError;
		/// <summary>
		/// �ʼ� �����̳� �����Դϴ�.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FrmIEConvPage()
		{
			//
			// Windows Form �����̳� ������ �ʿ��մϴ�.
			//
			InitializeComponent();

			//
			// TODO: InitializeComponent�� ȣ���� ���� ������ �ڵ带 �߰��մϴ�.
			//
			htFindWhat = new Hashtable();
			ReadCLSIDFromRegistry();
			FillDirectoryTree();
		}

		/// <summary>
		/// ��� ���� ��� ���ҽ��� �����մϴ�.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form �����̳ʿ��� ������ �ڵ�
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlFill = new System.Windows.Forms.Panel();
			this.btnConv = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.lbxIDS = new System.Windows.Forms.ListBox();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnRemoveCLSID = new System.Windows.Forms.Button();
			this.txtCLSID = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnRemoveResult = new System.Windows.Forms.Button();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.panel1 = new System.Windows.Forms.Panel();
			this.directoryTree = new System.Windows.Forms.TreeView();
			this.splitter2 = new System.Windows.Forms.Splitter();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.lbxFiles = new System.Windows.Forms.ListBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.txtFilter = new System.Windows.Forms.TextBox();
			this.chkAll = new System.Windows.Forms.CheckBox();
			this.lblError = new System.Windows.Forms.Label();
			this.pnlTop.SuspendLayout();
			this.pnlFill.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.Controls.Add(this.lblError);
			this.pnlTop.Controls.Add(this.chkAll);
			this.pnlTop.Controls.Add(this.btnRemoveResult);
			this.pnlTop.Controls.Add(this.label1);
			this.pnlTop.Controls.Add(this.txtCLSID);
			this.pnlTop.Controls.Add(this.btnRemoveCLSID);
			this.pnlTop.Controls.Add(this.btnAdd);
			this.pnlTop.Controls.Add(this.btnConv);
			this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlTop.Location = new System.Drawing.Point(0, 0);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(976, 96);
			this.pnlTop.TabIndex = 0;
			// 
			// pnlFill
			// 
			this.pnlFill.Controls.Add(this.panel1);
			this.pnlFill.Controls.Add(this.splitter1);
			this.pnlFill.Controls.Add(this.groupBox1);
			this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlFill.Location = new System.Drawing.Point(0, 96);
			this.pnlFill.Name = "pnlFill";
			this.pnlFill.Size = new System.Drawing.Size(976, 317);
			this.pnlFill.TabIndex = 1;
			// 
			// btnConv
			// 
			this.btnConv.Location = new System.Drawing.Point(8, 8);
			this.btnConv.Name = "btnConv";
			this.btnConv.TabIndex = 0;
			this.btnConv.Text = "��ȯ";
			this.btnConv.Click += new System.EventHandler(this.btnConv_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.lbxIDS);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(320, 317);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "���CLSID��";
			// 
			// lbxIDS
			// 
			this.lbxIDS.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbxIDS.ItemHeight = 12;
			this.lbxIDS.Location = new System.Drawing.Point(3, 17);
			this.lbxIDS.Name = "lbxIDS";
			this.lbxIDS.Size = new System.Drawing.Size(314, 292);
			this.lbxIDS.TabIndex = 0;
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(176, 8);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.TabIndex = 2;
			this.btnAdd.Text = "CLSID�߰�";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnRemoveCLSID
			// 
			this.btnRemoveCLSID.Location = new System.Drawing.Point(616, 8);
			this.btnRemoveCLSID.Name = "btnRemoveCLSID";
			this.btnRemoveCLSID.TabIndex = 4;
			this.btnRemoveCLSID.Text = "CLSID����";
			this.btnRemoveCLSID.Click += new System.EventHandler(this.btnRemoveCLSID_Click);
			// 
			// txtCLSID
			// 
			this.txtCLSID.Location = new System.Drawing.Point(256, 8);
			this.txtCLSID.Name = "txtCLSID";
			this.txtCLSID.Size = new System.Drawing.Size(352, 21);
			this.txtCLSID.TabIndex = 3;
			this.txtCLSID.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(272, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(384, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "ex) clsid:1F57AEAD-DB12-11D2-A4F9-00608CEBEE49";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// btnRemoveResult
			// 
			this.btnRemoveResult.Location = new System.Drawing.Point(88, 8);
			this.btnRemoveResult.Name = "btnRemoveResult";
			this.btnRemoveResult.TabIndex = 1;
			this.btnRemoveResult.Text = "��ȯ����";
			this.btnRemoveResult.Click += new System.EventHandler(this.btnRemoveResult_Click);
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(320, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(8, 317);
			this.splitter1.TabIndex = 1;
			this.splitter1.TabStop = false;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.splitter2);
			this.panel1.Controls.Add(this.directoryTree);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(328, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(648, 317);
			this.panel1.TabIndex = 2;
			// 
			// directoryTree
			// 
			this.directoryTree.Dock = System.Windows.Forms.DockStyle.Left;
			this.directoryTree.ImageIndex = -1;
			this.directoryTree.Location = new System.Drawing.Point(0, 0);
			this.directoryTree.Name = "directoryTree";
			this.directoryTree.SelectedImageIndex = -1;
			this.directoryTree.Size = new System.Drawing.Size(328, 317);
			this.directoryTree.TabIndex = 0;
			this.directoryTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.directoryTree_AfterSelect);
			this.directoryTree.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.directoryTree_BeforeExpand);
			// 
			// splitter2
			// 
			this.splitter2.Location = new System.Drawing.Point(328, 0);
			this.splitter2.Name = "splitter2";
			this.splitter2.Size = new System.Drawing.Size(8, 317);
			this.splitter2.TabIndex = 2;
			this.splitter2.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.lbxFiles);
			this.panel2.Controls.Add(this.panel3);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(336, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(312, 317);
			this.panel2.TabIndex = 4;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.txtFilter);
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(312, 24);
			this.panel3.TabIndex = 4;
			// 
			// lbxFiles
			// 
			this.lbxFiles.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbxFiles.ItemHeight = 12;
			this.lbxFiles.Location = new System.Drawing.Point(0, 24);
			this.lbxFiles.Name = "lbxFiles";
			this.lbxFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.lbxFiles.Size = new System.Drawing.Size(312, 292);
			this.lbxFiles.TabIndex = 5;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.label2);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(96, 24);
			this.panel4.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label2.Location = new System.Drawing.Point(0, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 24);
			this.label2.TabIndex = 0;
			this.label2.Text = "����:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// txtFilter
			// 
			this.txtFilter.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtFilter.Location = new System.Drawing.Point(96, 0);
			this.txtFilter.Name = "txtFilter";
			this.txtFilter.Size = new System.Drawing.Size(216, 21);
			this.txtFilter.TabIndex = 1;
			this.txtFilter.Text = "*.jsp";
			this.txtFilter.TextChanged += new System.EventHandler(this.txtFilter_TextChanged);
			// 
			// chkAll
			// 
			this.chkAll.Location = new System.Drawing.Point(8, 40);
			this.chkAll.Name = "chkAll";
			this.chkAll.Size = new System.Drawing.Size(248, 24);
			this.chkAll.TabIndex = 5;
			this.chkAll.Text = "CLSID�� ������� ��� OBJECT�� ��ȯ";
			// 
			// lblError
			// 
			this.lblError.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.lblError.Location = new System.Drawing.Point(8, 64);
			this.lblError.Name = "lblError";
			this.lblError.Size = new System.Drawing.Size(704, 23);
			this.lblError.TabIndex = 6;
			this.lblError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// FrmIEConvPage
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(976, 413);
			this.Controls.Add(this.pnlFill);
			this.Controls.Add(this.pnlTop);
			this.Name = "FrmIEConvPage";
			this.Text = "IE�� OBJECT �±� ��ȯ��";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.pnlTop.ResumeLayout(false);
			this.pnlFill.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// �ش� ���� ���α׷��� �� �������Դϴ�.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FrmIEConvPage());
		}

		private void btnConv_Click(object sender, System.EventArgs e)
		{
			if(this.directoryTree.SelectedNode == null)
			{
				MessageBox.Show("���� ������ �����Ͻʽÿ�.");
				return;
			}
			string	strPathSep = new string(Path.DirectorySeparatorChar,1);
			string	strPath = this.GetPathFromNode(this.directoryTree.SelectedNode) + strPathSep;
			InitHashtable();
			int			liCount = this.lbxFiles.SelectedItems.Count;
			if(liCount < 1)
			{
				MessageBox.Show("���� ������ �����Ͻʽÿ�.");
				return;
			}
			try
			{
				for(int i = 0 ; i <  liCount; ++i)
				{
					string	fileName = strPath + this.lbxFiles.SelectedItems[i].ToString();
					ConvFile(fileName);
				}
				MessageBox.Show("�۾��� ���� ����Ǿ����ϴ�.");
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private	void	ConvFile(string asFileName)
		{
			ITConvPage		lrConvPage = new ITConvPage(asFileName,this.htFindWhat);
			if(this.chkAll.Checked)
			{
				lrConvPage.SetIgnoreClsId(true);
			}
			lrConvPage.Process();
			lrConvPage.SaveResult();
		}
		private	void	RemoveTag(string asFileName)
		{
			ITConvPage		lrConvPage = new ITConvPage(asFileName,this.htFindWhat);
			lrConvPage.SaveContent();
		}
		private static string GetFromRegistry(string asSubKey,string asDefaultValue)
		{
			string			lsValue;
			RegistryKey Hklm = Registry.LocalMachine;
			RegistryKey HkSoftware = Hklm.OpenSubKey("Software",true);
			RegistryKey HkMy = HkSoftware.CreateSubKey(RegHome);
			lsValue = (string) HkMy.GetValue(asSubKey,null);
			if(lsValue == null)
			{
				HkMy.SetValue(asSubKey,asDefaultValue);
				lsValue = asDefaultValue;
			}
			HkMy.Close();
			HkSoftware.Close();
			return lsValue;
		}
		private static void SetToRegistry(string asSubKey,string asValue)
		{
			string			lsValue;
			RegistryKey Hklm = Registry.LocalMachine;
			RegistryKey HkSoftware = Hklm.OpenSubKey("Software",true);
			RegistryKey HkMy = HkSoftware.CreateSubKey(RegHome);
			lsValue = (string) HkMy.GetValue(asSubKey,null);
			HkMy.SetValue(asSubKey,asValue);
			HkMy.Close();
			HkSoftware.Close();
			return ;
		}
		private	void	ReadCLSIDFromRegistry()
		{
			this.lbxIDS.Items.Clear();
			string	strList = GetFromRegistry(CLSID_SUBKEY,"");
			string [] split = strList.Split(new char[]{','});
			for(int i = 0 ; i < split.Length ; ++i)
			{
				if(split[i] == "") continue;
				this.lbxIDS.Items.Add(split[i]);
			}

		}
		private	void	SaveCLSIDToRegistry()
		{
			string		strSave = "";
			int			iCount = this.lbxIDS.Items.Count;
			for ( int i = 0 ; i < iCount ; ++ i)
			{
				strSave += this.lbxIDS.Items[i].ToString();
				if( i == iCount - 1)
				{
					strSave += ",";
				}
			}
			SetToRegistry(CLSID_SUBKEY,strSave);
		}

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			if(this.lbxIDS.Items.IndexOf(this.txtCLSID.Text) >= 0)
			{
				MessageBox.Show("�ش� CLSID�� �̹� ��ϻ� �����մϴ�.");
				return;
			}
			this.lbxIDS.Items.Add(this.txtCLSID.Text);
			SaveCLSIDToRegistry();
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void btnRemoveCLSID_Click(object sender, System.EventArgs e)
		{
			if(this.lbxIDS.Items.Count < 1)
			{
				MessageBox.Show("������ �׸��� �����ϴ�.");
				return;
			}
			if(this.lbxIDS.SelectedIndex < 0)
			{
				MessageBox.Show("������ �׸��� �����Ͽ� �ֽʽÿ�.");
				return;
			}
			this.lbxIDS.Items.RemoveAt(this.lbxIDS.SelectedIndex);
			SaveCLSIDToRegistry();
		}
		private	void	InitHashtable()
		{
			htFindWhat.Clear();
			int			iCount = this.lbxIDS.Items.Count;
			for ( int i = 0 ; i < iCount ; ++ i)
			{
				string	strTemp = this.lbxIDS.Items[i].ToString().ToLower();
				htFindWhat[strTemp] = strTemp;
			}
		}

		private void btnRemoveResult_Click(object sender, System.EventArgs e)
		{
			if(this.directoryTree.SelectedNode == null)
			{
				MessageBox.Show("���� ������ �����Ͻʽÿ�.");
				return;
			}
			string	strPathSep = new string(Path.DirectorySeparatorChar,1);
			string	strPath = this.GetPathFromNode(this.directoryTree.SelectedNode) + strPathSep;
			int			liCount = this.lbxFiles.SelectedItems.Count;
			if(liCount < 1)
			{
				MessageBox.Show("���� ������ �����Ͻʽÿ�.");
				return;
			}
			for(int i = 0 ; i <  liCount; ++i)
			{
				string	fileName = strPath + this.lbxFiles.SelectedItems[i].ToString();
				this.RemoveTag(fileName);
			}
			MessageBox.Show("�۾��� ���� ����Ǿ����ϴ�.");
		}
		private void FillDirectoryTree() 
		{
			string[] drives = Environment.GetLogicalDrives();
			for (int i = 0; i < drives.Length; i++) 
			{
				if (PlatformInvokeKernel32.GetDriveType(drives[i]) == PlatformInvokeKernel32.DRIVE_FIXED) 
				{
					DirectoryNode cRoot = new DirectoryNode(drives[i]);
					directoryTree.Nodes.Add(cRoot);
					AddDirectories(cRoot);
				}
			}
		}
		private void AddDirectories(TreeNode node) 
		{
			try 
			{
				DirectoryInfo dir = new DirectoryInfo(GetPathFromNode(node));
				DirectoryInfo[] e = dir.GetDirectories();

				for (int i = 0; i < e.Length; i++) 
				{
					string name = e[i].Name;
					if (!name.Equals(".") && !name.Equals("..")) 
					{
						node.Nodes.Add(new DirectoryNode(name));
					}
				}
			}
			catch (Exception e) 
			{
				lblError.Text = e.Message;
			}
		}
		private string GetPathFromNode(TreeNode node) 
		{
			if(node == null) return "";
			if (node.Parent == null) 
			{
				return node.Text;
			}
			
			return Path.Combine(GetPathFromNode(node.Parent), node.Text);
		}

		private void directoryTree_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			DirectoryNode nodeSelect = (DirectoryNode)e.Node;
			string	strPath = GetPathFromNode(nodeSelect);
			displayFileList(strPath);
		}
		private	void	displayFileList(string asPath)
		{
			this.lbxFiles.Items.Clear();
			if(asPath == "") return;
			try 
			{
				DirectoryInfo dir = new DirectoryInfo(asPath);
				FileSystemInfo[] e = dir.GetFileSystemInfos(this.txtFilter.Text);

				for (int i = 0; i < e.Length; i++) 
				{
					string name = e[i].Name;
					if (!name.Equals(".") && !name.Equals("..")) 
					{
						this.lbxFiles.Items.Add(name);
					}
				}
			}
			catch (Exception e) 
			{
				MessageBox.Show(e.Message);
			}
		}
		private void directoryTree_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			DirectoryNode nodeExpanding = (DirectoryNode)e.Node;
			if (!nodeExpanding.SubDirectoriesAdded)
				AddSubDirectories(nodeExpanding);
		
		}
		private void AddSubDirectories(DirectoryNode node) 
		{
			for (int i = 0; i < node.Nodes.Count; i++) 
			{
				AddDirectories(node.Nodes[i]);
			}
			node.SubDirectoriesAdded = true;
		}

		private void txtFilter_TextChanged(object sender, System.EventArgs e)
		{
			this.displayFileList(GetPathFromNode(this.directoryTree.SelectedNode));
		}
	}
}
