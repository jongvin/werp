using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace IEConvPage
{
	/// <summary>
	/// ITConvPage�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ITConvPage
	{
		static		private			Regex			headRegex = new Regex(@"<\s*object",RegexOptions.IgnoreCase | RegexOptions.Compiled);
		static		private			Regex			clsidRegex = new Regex("classid\\s*=",RegexOptions.IgnoreCase | RegexOptions.Compiled);
		static		private			Regex			whiteSpaceRegex = new Regex(@"\s|>",RegexOptions.IgnoreCase | RegexOptions.Compiled);
		static		private			Regex			tailRegex = new Regex(@"<\s*/\s*object\s*>",RegexOptions.IgnoreCase | RegexOptions.Compiled);
		static		private			string			REMOVE_TAG_HEAD = "<!--CONVPAGE_HEAD ������������//-->";
		static		private			string			REMOVE_TAG_TAIL = "<!--CONVPAGE_TAIL ������������//-->";

		public		ITConvPage(string asFileName,Hashtable ahFindWhat)
		{
			iChangeCount_ = 0;
			strFileName_ = asFileName;
			htFindClsId_ = ahFindWhat;
			strResult_ = "";
			StreamReader	sr = null;
			try
			{
				sr = new StreamReader(asFileName,System.Text.Encoding.Default);

				string	strTemp = sr.ReadToEnd();
				RemoveResult(ref strTemp,ref strFileContents_);
				return ;
			}
			finally
			{
				if(sr != null) sr.Close();
			}
		}
		public		void	SaveResult()
		{
			StreamWriter	sw = null;
			if(iChangeCount_ <= 0) return;
			try
			{
				sw = new StreamWriter(strFileName_,false,System.Text.Encoding.Default);
				sw.Write(strResult_);
				return ;
			}
			finally
			{
				if(sw != null) sw.Close();
			}
		}
		public		void	SaveContent()
		{
			StreamWriter	sw = null;
			try
			{
				sw = new StreamWriter(strFileName_,false,System.Text.Encoding.Default);
				sw.Write(strFileContents_);
				return ;
			}
			finally
			{
				if(sw != null) sw.Close();
			}
		}
		public		void	Process()
		{
			iProcessPosition_ = 0;
			iProcessCount_ = 0;
			while(ProcessOneElem());
		}
		public		void	SetIgnoreClsId(bool abTag)
		{
			this.bIgnoreClsId = abTag;
		}
		public		bool	GetIgnoreClsId()
		{
			return this.bIgnoreClsId;
		}
		public	string	getResult()
		{
			return strResult_;
		}
		private		bool			ProcessOneElem()
		{
			Match m;
			m = headRegex.Match(this.strFileContents_,iProcessPosition_);
			if(m.Success)
			{

				iFindPos_ = m.Index;
				strResult_ += strFileContents_.Substring(iProcessPosition_,iFindPos_ - iProcessPosition_);
				int			liEndPos = FindEndPosition();
				if(liEndPos < 0)
				{
					throw new Exception("OBJECT �±��� ���κ��� ã�� �� �����ϴ�.");
				}
				if(!IsTargetClsId())
				{
					strResult_ += strFileContents_.Substring(iFindPos_,liEndPos - iFindPos_);
					iProcessPosition_ = liEndPos;
					return true;
				}
				else
				{
					iProcessCount_++;
					iChangeCount_++;
					string		lstrID = "__NSID__"+iProcessCount_.ToString();
					strResult_ += REMOVE_TAG_HEAD;
					strResult_ += " <comment id=\"";
					strResult_ += lstrID;
					strResult_ += "\"> ";
					strResult_ += REMOVE_TAG_TAIL;
					strResult_ += strFileContents_.Substring(iFindPos_,liEndPos - iFindPos_);
					strResult_ += REMOVE_TAG_HEAD;
					strResult_ += "</comment> <script> __WS__(";
					strResult_ += lstrID;
					strResult_ += "); </script> ";
					strResult_ += REMOVE_TAG_TAIL;
					iProcessPosition_ = liEndPos;
					return true;
				}
			}
			else
			{
				strResult_ += strFileContents_.Substring(iProcessPosition_);
			}
			return false;
		}
		private		void	RemoveResult(ref string asSrc,ref string asDst)
		{
			asDst = "";
			int			liPos = 0;
			while(true)
			{
				int	liNewPos = asSrc.IndexOf(REMOVE_TAG_HEAD,liPos);
				if(liNewPos < 0)
				{
					asDst += asSrc.Substring(liPos);
					break;
				}
				iChangeCount_++;
				asDst += asSrc.Substring(liPos,liNewPos - liPos);
				int	liEndPos = asSrc.IndexOf(REMOVE_TAG_TAIL,liNewPos);
				if(liEndPos < 0)
				{
					asDst += asSrc.Substring(liNewPos);
				}
				liPos = liEndPos + REMOVE_TAG_TAIL.Length;
			}
		}
		private		bool	IsTargetClsId()
		{
			if(this.bIgnoreClsId) return true;
			Match m;
			m = clsidRegex.Match(this.strFileContents_,iFindPos_);
			if(m.Success)
			{
				int			liPos = m.Index;
				Match sm = whiteSpaceRegex.Match(this.strFileContents_,liPos+m.Value.Length);
				if(sm.Success)
				{
					string		sValue = this.strFileContents_.Substring(liPos+m.Value.Length,sm.Index - (liPos+m.Value.Length));
					sValue = sValue.Replace("\"","");
					sValue = sValue.Replace("\'","");
					return this.htFindClsId_.ContainsKey(sValue.ToLower());
				}
				else
				{
					throw new Exception("classid�� ���� ã�� �� �����ϴ�.");
				}
			}
			else
			{
				throw new Exception("classid�� ã�� �� �����ϴ�.");
			}
		}
		private		int		FindEndPosition()
		{
			Match m;
			m = tailRegex.Match(this.strFileContents_,iFindPos_);
			if(m.Success)
			{

				return m.Index + m.Value.Length;
			}
			else
			{
				return -1;
			}
		}
		private		string			strFileContents_;
		private		string			strResult_;
		private		Hashtable		htFindClsId_;
		private		string			strFileName_;
		private		int				iProcessPosition_;
		private		int				iFindPos_;
		private		int				iProcessCount_;
		private		bool			bIgnoreClsId = false;
		private		int				iChangeCount_;
	}
}
