/* ============================================================================= */
/* �Լ��� : y_sp_h_base_sellhouse                                                */
/* ��  �� : ���޼��� �ϰ�ó��                                                    */
/* ----------------------------------------------------------------------------- */
/* ��  �� : �����ڵ�               ==> as_dept_code (string)                     */
/*        : �о籸��               ==> as_sell_code(String) 	                  */
/*        : ����                   ==> ai_seq(Number) 			                  */
/* ===========================[ ��   ��   ��   �� ]============================= */
/* �ۼ��� : �赿��                                                               */
/* �ۼ��� : 2003.11.14                                                           */
/* ============================================================================= */
CREATE OR REPLACE PROCEDURE y_sp_h_base_sellhouse(as_dept_code IN   VARCHAR2,
                                                  as_sell_code IN   VARCHAR2,
																  ai_seq       IN NUMBER ) IS

-------------------------------------------------------------
-- ��������
-------------------------------------------------------------
-- ���� ���� 
   Wk_errmsg           VARCHAR2(500);              -- Error Message Edit
   Wk_errflag          INTEGER        DEFAULT 0;   -- Process Error Code
   e_msg               VARCHAR2(100);

-- User Define Error 
   V_DONG              h_base_sellhouse.S_DONG%TYPE;    -- 
   V_S_HO              h_base_sellhouse.S_HO%TYPE;    -- 
   V_E_HO              h_base_sellhouse.E_HO%TYPE;    -- 
   V_PYONG             h_base_sellhouse.PYONG%TYPE;    -- 
   V_STYLE             h_base_sellhouse.STYLE%TYPE;    -- 
   V_CLASS             h_base_sellhouse.CLASS%TYPE;    -- 
   V_OPTION_CODE       h_base_sellhouse.OPTION_CODE%TYPE;    -- 
   V_CONTRACT_CODE     h_base_sellhouse.CONTRACT_CODE%TYPE;    -- 
   V_UNION_YN          h_base_sellhouse.UNION_YN%TYPE;    -- 
   V_MOVEINTO_FR_DATE  h_code_house.MOVEINTO_FR_DATE%TYPE;    -- 
   V_MOVEINTO_TO_DATE  h_code_house.MOVEINTO_TO_DATE%TYPE;    -- 
   C_S_HO1             INTEGER DEFAULT 0;
   C_S_HO2             INTEGER DEFAULT 0;
   C_E_HO1             INTEGER DEFAULT 0;
   C_E_HO2             INTEGER DEFAULT 0;
	C_CHK               VARCHAR2(2);
	C_DONGHO            VARCHAR2(8);
	C_HO1               VARCHAR2(8);
	C_HO2               VARCHAR2(8);
   C_CNT               NUMBER(20,5);  -- 
   C_CNT1              NUMBER(20,5);  -- 
   C_CNT2              NUMBER(20,5);  -- 
   C_TOT_CNT           NUMBER(20,5);  -- 
 
   UserErr         EXCEPTION;                  -- Select Data Not Found
BEGIN
  BEGIN
		select pyong,style,class,s_dong,to_number(substr(s_ho,1,2)),to_number(substr(s_ho,3,2)),
				 to_number(substr(e_ho,1,2)),to_number(substr(e_ho,3,2)),option_code,union_yn,contract_code
		  into V_PYONG,V_STYLE,V_CLASS,V_DONG,C_S_HO1,C_S_HO2,C_E_HO1,C_E_HO2,V_OPTION_CODE,V_UNION_YN,V_CONTRACT_CODE
		  from h_base_sellhouse
		 where dept_code = as_dept_code
			and sell_code = as_sell_code
			and seq       = ai_seq;

		select moveinto_fr_date,moveinto_to_date
		  into V_MOVEINTO_FR_DATE,V_MOVEINTO_TO_DATE
		  from h_code_house
		 where dept_code = as_dept_code
			and sell_code = as_sell_code;

		IF V_UNION_YN = 'Y' THEN
			C_CHK := '03';
		ELSE
			C_CHK := '01';
		END IF;

		IF C_S_HO1 <= C_E_HO1 AND C_S_HO2 <= C_E_HO2 THEN
			C_CNT1 := C_S_HO1;
			C_TOT_CNT := 0;
			LOOP
				C_CNT2 := C_S_HO2;
				LOOP
					IF C_CNT1 < 10 THEN
						C_HO1 := '0' || TO_CHAR(C_CNT1);
					ELSE
						C_HO1 := TO_CHAR(C_CNT1);
					END IF;
					IF C_CNT2 < 10 THEN
						C_HO2 := '0' || TO_CHAR(C_CNT2);
					ELSE
						C_HO2 := TO_CHAR(C_CNT2);
					END IF;

					C_DONGHO := V_DONG || C_HO1 || C_HO2;

					select COUNT(*)
					  into C_CNT
					  from h_sale_master
					 where dept_code = as_dept_code
						and sell_code = as_sell_code
						and dongho    = C_DONGHO;

					IF C_CNT < 1 THEN
						INSERT INTO H_SALE_MASTER  
							VALUES ( as_dept_code,as_sell_code,C_DONGHO,1,V_PYONG,V_STYLE,V_CLASS,V_OPTION_CODE,   
										'','','',V_CONTRACT_CODE,'N',to_date('1000.01.01'),'00',to_date('2999.12.31'),to_date('1000.01.01'),0,0,0,0,'',0,'',null,'',null,'',null,'',V_MOVEINTO_FR_DATE,V_MOVEINTO_TO_DATE,'' )  ;

						INSERT INTO H_SALE_AGREE  
						  SELECT b.DEPT_CODE,b.SELL_CODE,C_DONGHO,1,b.DEGREE_CODE,b.AGREE_DATE,b.LAND_AMT,b.BUILD_AMT,
									b.VAT_AMT,b.SELL_AMT,'N',0,null,0  
							 FROM h_base_pyong_master a,
									( select *
										 from	H_BASE_PYONG_DETAIL ) b
							where a.dept_code = b.dept_code (+)
							  and a.sell_code = b.sell_code (+)
							  and a.spec_unq_num = b.spec_unq_num (+)
							  and a.dept_code = as_dept_code
							  and a.sell_code = as_sell_code
							  and a.pyong = V_PYONG
							  and a.style = V_STYLE
							  and a.class = V_CLASS
							  and a.option_code = V_OPTION_CODE;

						INSERT INTO h_sale_delay_rate
							SELECT dept_code,sell_code,C_DONGHO,1,rate_kind,s_days,e_days,s_date,e_date,rate,
									 cutoff_std,cutoff_unit
							  FROM h_base_delay_rate
							 WHERE dept_code = as_dept_code
								AND sell_code = as_sell_code;

						INSERT INTO h_sale_discount_rate
							SELECT dept_code,sell_code,C_DONGHO,1,rate_kind,s_date,e_date,rate,cutoff_std,cutoff_unit
							  FROM h_base_discount_rate
							 WHERE dept_code = as_dept_code
								AND sell_code = as_sell_code;
					END IF;					
					C_CNT2 := C_CNT2 + 1;
					C_TOT_CNT := C_TOT_CNT + 1;
					IF C_CNT2 > C_E_HO2 THEN
						EXIT;
					END IF;
				END LOOP;

				C_CNT1 := C_CNT1 + 1;
				IF C_CNT1 > C_E_HO1 THEN
					EXIT;
				END IF;
			
			END LOOP;

			UPDATE H_BASE_SELLHOUSE  
			   SET HOUSE_CNT = C_TOT_CNT  
			 WHERE DEPT_CODE = as_dept_code
				AND sell_code = as_sell_code
				AND seq       = ai_seq;

		END IF;

      EXCEPTION
      WHEN others THEN 
           IF SQL%NOTFOUND THEN
              e_msg      := '���޼��� �ϰ����� ����! [Line No: 2]';
              Wk_errflag := -20020;
         
              GOTO EXIT_ROUTINE;
           END IF;   
 END;

   -- *****************************************************************************
   -- PROCESS ENDDING ... !
   -- *****************************************************************************
   <<EXIT_ROUTINE>>
   
   -- ENDING...[0.1] CURSOR CLOSE �� Ȯ�� ó�� !
   IF Wk_errflag = 0 THEN
      Wk_errmsg  := '';                        -- ����� ���� Error Message
      Wk_errflag := 0;                         -- ����� ���� Error Code
   ELSE 
      Wk_errmsg := RTRIM(e_msg) || '/>';
      RAISE UserErr;
   END IF;

EXCEPTION
  WHEN UserErr       THEN
       RAISE_APPLICATION_ERROR(Wk_errflag, Wk_errmsg);
END y_sp_h_base_sellhouse;

/
