/* ============================================================================= */
/* �Լ��� : y_sp_h_name_chg_insert                                               */
/* ��  �� : ���Ǻ���� ���γ����� �����Ѵ�.                                      */
/* ----------------------------------------------------------------------------- */
/* ��  �� : �����ڵ�               ==> as_dept_code (string)                     */
/*        : �о籸��               ==> as_sell_code (string)	                  */
/*        : ������ȣ               ==> as_dongho (string)	                     */
/*        : ���浿ȣ               ==> as_cdongho (string)	                     */
/*        : ��������               ==> as_b_seq (number)	                        */
/*        : ����                   ==> as_seq (number)	                        */
/* ===========================[ ��   ��   ��   �� ]============================= */
/* �ۼ��� : �赿��                                                               */
/* �ۼ��� : 2003.11.26                                                           */
/* ============================================================================= */
CREATE OR REPLACE PROCEDURE y_sp_h_name_chg_insert(as_dept_code    IN   VARCHAR2,
                                                   as_sell_code    IN   VARCHAR2,
                                                   as_dongho       IN   VARCHAR2,
                                                   as_cdongho      IN   VARCHAR2,
                                                   as_b_seq        IN   INTEGER,
                                                   as_seq          IN   INTEGER) IS

-------------------------------------------------------------
-- ��������
-------------------------------------------------------------
-- ���� ���� 
   Wk_errmsg           VARCHAR2(500);              -- Error Message Edit
   Wk_errflag          INTEGER        DEFAULT 0;   -- Process Error Code
   e_msg               VARCHAR2(100);

-- User Define Error 
   C_LEVEL              NUMBER(20,5);  -- 
   C_CNT                NUMBER(20,5);  -- 
 
   UserErr         EXCEPTION;                  -- Select Data Not Found
BEGIN
  BEGIN
-- ���뺰 ���񽺿ɼ� ����
	begin
		INSERT INTO H_SALE_OPTION  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CLS_CODE,ELEM_CODE,REMARK  
			 FROM H_SALE_OPTION  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 ���񽺿ɼ� ���� ����! [Line No: 1]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 �������� ����
	begin
	  INSERT INTO H_SALE_AGREE  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,DEGREE_CODE,AGREE_DATE,LAND_AMT,BUILD_AMT,   
					VAT_AMT,SELL_AMT,F_PAY_YN,TOT_AMT,WORK_DATE,WORK_NO
			 FROM H_SALE_AGREE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 �������� ���� ����! [Line No: 1]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 ���Ա� ����
	begin
		INSERT INTO H_SALE_INCOME  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,DEGREE_CODE,DEGREE_SEQ,RECEIPT_DATE,RECEIPT_CODE,DEPOSIT_NO,   
					R_AMT,R_LAND_AMT,R_BUILD_AMT,R_VAT_AMT,DELAY_DAYS,DELAY_AMT,DISCOUNT_DAYS,DISCOUNT_AMT,INPUT_ID,   
					INPUT_DATE,WORK_DATE,WORK_NO,TAX_DATE,TAX_NO,MODI_YN, null, null, null, null   
			 FROM H_SALE_INCOME  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 ���Ա� ���� ����! [Line No: 2]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 �������ñ�� ����
	begin
		INSERT INTO H_SALE_FUND  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,REQUEST_DATE,REQUEST_R_AMT,EXCHANGE_DATE,PROCESS_YN  
			 FROM H_SALE_FUND  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 �������ñ�� ���� ����! [Line No: 3]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 �ؾ���� ����
	begin
		INSERT INTO H_SALE_ANNUL  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,REFUND_DATE,PENALTY,TERM_INTEREST,INCOME_TAX,
					RESIDENCE_TAX,LEASE_DEDUCT_AMT,SUBTR_AMT,LOAN_CAP,REFUND_AMT,BANK_HEAD_CODE,DEPOSIT_NO,ANNUL_REASON  
			 FROM H_SALE_ANNUL  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 �ؾ���� ���� ����! [Line No: 4]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 �������� ����
	begin
		INSERT INTO H_SALE_DOCUMENT  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,ISSUE_DATE,ISSUE_DOCUMENT,ISSUE_NO,   
					ISSUER,ISSUE_REASON,REMARK  
			 FROM H_SALE_DOCUMENT  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 �������� ���� ����! [Line No: 5]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 On-Time���� ����
	begin
		INSERT INTO H_SALE_ONTIME_MASTER  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,ITEM_CODE,ITEM_SIZE,CONTRACT_DATE,REMARK  
			 FROM H_SALE_ONTIME_MASTER  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 On-Time���� ���� ����! [Line No: 6]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 �޸���� ����
	begin
		INSERT INTO H_SALE_MEMO  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,INPUT_DATE,INPUT_SEQ,TITLE,   
					CONTENTS,RECORD_DUTY_ID,IDENTIFY_DATE,FINISH_YN 
			 FROM H_SALE_MEMO  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 �޸���� ���� ����! [Line No: 7]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 Ư�̻��� ����
	begin
		INSERT INTO H_SALE_ETC
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,UNIQUE_DIV,EFFECT_NO,DELIVERY_DATE,
					CREDITOR,BOND_AMT,CANCEL_YN,CANCEL_DATE,REMARK,CANCEL_DESC,INPUT_ID 
			 FROM H_SALE_ETC  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 Ư�̻��� ���� ����! [Line No: 8]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 ���������⳻�� ����
	begin
		INSERT INTO H_SALE_LOAN  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,BANK_HEAD_CODE,LOAN_REQUEST_DATE,   
					LOAN_REQUEST_AMT,GUARANTEE_SOL_DATE,LOAN_DUTY_NAME,LOAN_DUTY_PHONE,REMARK  
			 FROM H_SALE_LOAN  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 ���������⳻�� ���� ����! [Line No: 9]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 On-Time�������� ����
	begin
		INSERT INTO H_SALE_ONTIME_AGREE  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,DEGREE_CODE,AGREE_DATE,AGREE_AMT,F_PAY_YN,TOT_AMT  
			 FROM H_SALE_ONTIME_AGREE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 On-Time�������� ���� ����! [Line No: 10]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰 On-Time���Ա� ����
	begin
		INSERT INTO H_SALE_ONTIME_INCOME  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,DEGREE_CODE,DEGREE_SEQ,RECEIPT_DATE,RECEIPT_CODE,
					DEPOSIT_NO,R_AMT,DELAY_DAYS,DELAY_AMT,DISCOUNT_DAYS,DISCOUNT_AMT,WORK_DATE,WORK_NO, 
					INPUT_ID,INPUT_DATE,MODI_YN, null, null, null, null     
			 FROM H_SALE_ONTIME_INCOME  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰 On-Time���Ա� ���� ����! [Line No: 11]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- �Ӵ���� ����
	begin
		INSERT INTO H_LEAS_MASTER  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CONTRACT_DATE,CONTRACT_DIV,CUST_CODE,HOUSE_TYPE,VAT_YN,   
					GUARANTEE_AMT,LEASE_SUPPLY,LEASE_VAT,S_DATE,E_DATE,MOVEINTO_DATE,REAL_NAME  
	       FROM H_LEAS_MASTER  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '�Ӵ���� ���� ����! [Line No: 12]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- �Ӵ��������� ����
	begin
		INSERT INTO H_LEAS_LEASE_AGREE  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CONTRACT_DATE,DEGREE_CODE,AGREE_DATE,S_DATE,E_DATE,DAYS,   
					LEASE_AMT,VAT_YN,LEASE_SUPPLY,LEASE_VAT,F_PAY_YN,PAY_TOT_AMT  
			 FROM H_LEAS_LEASE_AGREE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '�Ӵ��������� ���� ����! [Line No: 13]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- �Ӵ�ᳳ�Ի��� ����
	begin
	  INSERT INTO H_LEAS_LEASE_INCOME  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CONTRACT_DATE,DEGREE_CODE,DEGREE_SEQ,RECEIPT_DATE,DEPOSIT_NO,
					R_AMT,LEASE_SUPPLY,LEASE_VAT,DELAY_DAYS,DELAY_AMT,DISCOUNT_DAYS,DISCOUNT_AMT,WORK_DATE,WORK_NO,
					INPUT_ID,INPUT_DATE,MODI_YN 
			 FROM H_LEAS_LEASE_INCOME  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '�Ӵ�ᳳ�Ի��� ���� ����! [Line No: 14]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- �Ӵ뺸���ݾ��� ����
	begin
		INSERT INTO H_LEAS_GUARANTEE_AGREE  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CONTRACT_DATE,DEGREE_CODE,AGREE_DATE,GUARANTEE_AMT,F_PAY_YN,TOT_AMT  
			 FROM H_LEAS_GUARANTEE_AGREE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '�Ӵ뺸���ݾ��� ���� ����! [Line No: 15]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- �Ӵ뺸���ݳ��� ����
	begin
		INSERT INTO H_LEAS_GUARANTEE_INCOME  
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,CONTRACT_DATE,DEGREE_CODE,DEGREE_SEQ,GUARANTEE_RECEIPT_DATE,   
					DEPOSIT_NO,R_AMT,DELAY_DAYS,DELAY_AMT,DISCOUNT_DAYS,DISCOUNT_AMT,WORK_DATE,WORK_NO,
					INPUT_ID,INPUT_DATE,MODI_YN  
			 FROM H_LEAS_GUARANTEE_INCOME  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '�Ӵ뺸���ݾ��� ���� ����! [Line No: 16]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰��ü�� ����
	begin
		INSERT INTO H_SALE_DELAY_RATE 
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,RATE_KIND,S_DAYS,E_DAYS,S_DATE,E_DATE,RATE,CUTOFF_STD,CUTOFF_UNIT
			 FROM H_SALE_DELAY_RATE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰��ü�� ���� ����! [Line No: 16]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
-- ���뺰������ ����
	begin
		INSERT INTO H_SALE_DISCOUNT_RATE 
		  SELECT DEPT_CODE,SELL_CODE,as_cdongho,as_seq,RATE_KIND,S_DATE,E_DATE,RATE,CUTOFF_STD,CUTOFF_UNIT
			 FROM H_SALE_DISCOUNT_RATE  
			WHERE DEPT_CODE = as_dept_code
			  AND	SELL_CODE = as_sell_code
			  AND DONGHO    = as_dongho
			  AND SEQ       = as_b_seq;

		EXCEPTION
		WHEN others THEN 
			  IF SQL%NOTFOUND THEN
				  e_msg      := '���뺰������ ���� ����! [Line No: 16]';
				  Wk_errflag := -20020;
			
				  GOTO EXIT_ROUTINE;
			  END IF;   
	end;
 END;

   -- *****************************************************************************
   -- PROCESS ENDDING ... !
   -- *****************************************************************************
   <<EXIT_ROUTINE>>
   
   -- ENDING...[0.1] CURSOR CLOSE �� Ȯ�� ó�� !
   IF Wk_errflag = 0 THEN
      Wk_errmsg  := '';                        -- ����� ���� Error Message
      Wk_errflag := 0;                         -- ����� ���� Error Code
   ELSE 
      Wk_errmsg := RTRIM(e_msg) || '/>';
      RAISE UserErr;
   END IF;

EXCEPTION
  WHEN UserErr       THEN
       RAISE_APPLICATION_ERROR(Wk_errflag, Wk_errmsg);
END y_sp_h_name_chg_insert;

/
