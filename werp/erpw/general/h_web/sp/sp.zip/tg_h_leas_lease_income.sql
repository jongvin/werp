/* ========================================================================= */
/* �ý��� : �о����                                                         */
/* �Լ��� : tg_h_leas_lease_income(�о�_�Ӵ����Ա��Է�,����,����)          */
/* ��  �� : �о��Ӵ�� ���Աݺ���� �α�ȭ�Ͽ� �߰��Ѵ�                      */
/* ===========================[ ��   ��   ��   �� ]========================= */
/*      �� �� ��    ��     ��             �� �� ��      ��         ��        */
/*   ------------  -------------------  ------------  ---------------------- */
/*   1. �赿��                           2004.03.04       �����ۼ�           */
/* ========================================================================= */

CREATE or REPLACE	TRIGGER tg_h_leas_lease_income
	BEFORE INSERT OR UPDATE OR DELETE ON h_leas_lease_income
		FOR EACH ROW

DECLARE
	errnum   CHAR(6):= '-20999';

BEGIN
	IF inserting THEN
		insert into h_log_leas_lease_income
			  values (:new.dept_code,:new.sell_code,:new.dongho,:new.seq,:new.contract_date,:new.degree_code,:new.degree_seq,
						 sysdate,h_spec_unq_no.nextval,'I',:new.receipt_date,:new.deposit_no,:new.r_amt,:new.lease_supply,:new.lease_vat,
						 :new.delay_days,:new.delay_amt,:new.discount_days,:new.discount_amt,
						 :new.work_date,:new.work_no,:new.input_id);
	END IF;

	IF updating THEN
		insert into h_log_leas_lease_income
			  values (:new.dept_code,:new.sell_code,:new.dongho,:new.seq,:new.contract_date,:new.degree_code,:new.degree_seq,
						 sysdate,h_spec_unq_no.nextval,'U',:new.receipt_date,:new.deposit_no,:new.r_amt,:new.lease_supply,:new.lease_vat,
						 :new.delay_days,:new.delay_amt,:new.discount_days,:new.discount_amt,
						 :new.work_date,:new.work_no,:new.input_id);
	END IF;
			
	IF deleting THEN
		insert into h_log_leas_lease_income
			  values (:old.dept_code,:old.sell_code,:old.dongho,:old.seq,:old.contract_date,:old.degree_code,:old.degree_seq,
						 sysdate,h_spec_unq_no.nextval,'D',:old.receipt_date,:old.deposit_no,:old.r_amt,:old.lease_supply,:old.lease_vat,
						 :old.delay_days,:old.delay_amt,:old.discount_days,:old.discount_amt,
						 :old.work_date,:old.work_no,:old.input_id);
	END IF;
             
END tg_h_leas_lease_income ;
/
