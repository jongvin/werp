CREATE OR REPLACE PROCEDURE SP_L_PAY_CLOSING(
												as_dept_code  IN  VARCHAR2,
												as_work_yymm  IN   DATE,   -- �⿪���
												as_seq        IN   NUMBER,   -- ���޼���
												as_slip_seq   IN   NUMBER,     -- ��ǥ����
												as_empno      IN   VARCHAR2,	 -- �α��λ��
												as_as_wbs_code IN VARCHAR2) IS -- ǰ������������ڵ� 
-------------------------------------------------------------
-- ��������
-------------------------------------------------------------
-- ���� ����
	Wk_errmsg           VARCHAR2(500);              -- Error Message Edit
	Wk_errflag          INTEGER        DEFAULT 0;   -- Process Error Code
	e_msg               VARCHAR2(100);	
-- User Define Error
   C_UNQ_NUM              F_REQUEST.SLIP_SPEC_UNQ_NUM%TYPE;    -- ��ǥ������ȣ
   C_PAY_DATE			  DATE;

   UserErr         EXCEPTION;                  -- Select Data Not Found
BEGIN
  BEGIN
   
-- �������� ���ϱ�
   SELECT pay_date INTO C_PAY_DATE
   FROM l_labor_monthlywork
   WHERE dept_code = as_dept_code
     and work_yymm = as_work_yymm
	 and seq = as_seq
   GROUP BY pay_date;
        
-- ����,��ä �ο���
      SELECT  f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       1,
       'L', --�ڿ�����
       '1', --���뱸��
       '�빫�� ����(���� '||sum(decode(b.cost_tag,'Y',1,0))||'��, ��ä '||sum(decode(b.cost_tag,'N',1,0))||'��)',
       sum(a.pay_amt),
             max(a.acntcode) acntcode,
         '2', --�ڱݱ���
         '3', --��������
         '1', --����/û������
       C_PAY_DATE,
	   as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;

-- �ӱݼҵ漼
      SELECT f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       2,
       'L',
       '2',
       '������(�ӱݼҵ漼)',
       sum(a.income_tax),
             '211813',
         '2',
         '3',
         '1',
       C_PAY_DATE,
	    as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;
    
-- �ӱ��ֹμ�
      SELECT f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       3,
       'L',
       '2',
       '������(�ӱ��ֹμ�)',
       sum(a.civil_tax),
             '211814',
         '2',
         '3',
         '1',
       C_PAY_DATE,
	   as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;
    
-- �ӱݱ��ο���
      SELECT f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       4,
       'L',
       '2',
       '������(���ο���)',
       sum(a.people_pension),
             '211822',
         '2',
         '3',
         '1',
       C_PAY_DATE,
	   as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;
    
-- �ӱ��ǷẸ���
      SELECT f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       5,
       'L',
       '2',
       '������(�ǰ�����)',
       sum(a.medical_tax),
             '211821',
         '2',
         '3',
         '1',
       C_PAY_DATE,
	   as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;
    
-- �ӱݰ��뺸���
      SELECT f_spec_unq_num.nextval
        INTO C_UNQ_NUM
        FROM dual;

    INSERT INTO f_request (dept_code, rqst_date, slip_seq, slip_spec_unq_num, seq,
      res_type, cr_class, cont, amt, acntcode, fund_type, cost_type, receipt_rqst_type, receipt_date,wbs_code,mdfy_yn)
    SELECT as_dept_code,
       C_PAY_DATE,
       as_slip_seq,
     C_UNQ_NUM,
       6,
       'L',
       '2',
       '������(���뺸���)',
       sum(a.insurance_tax),
             '211823',
         '2',
         '3',
         '1',
       C_PAY_DATE,
	   as_as_wbs_code,
	     'N'
        FROM l_labor_monthlywork a,
             l_labor_basic b
      WHERE a.dept_code = b.dept_code
    and a.spec_no   = b.spec_no
    and a.dept_code = as_dept_code
    and a.work_yymm  = as_work_yymm
    and a.seq       = as_seq ;
    
-- �빫���������̺� update
    UPDATE l_labor_monthlywork
   SET rqst_date = C_PAY_DATE, slip_seq = as_slip_seq, close_tag = 'T', 
       close_user = (SELECT emp_name FROM p_pers_master WHERE emp_no = as_empno)
     WHERE dept_code  = as_dept_code
       AND work_yymm  = as_work_yymm
     AND seq    = as_seq ;

      EXCEPTION
      WHEN others THEN
           IF SQL%NOTFOUND THEN
              e_msg      := '����ó�� ����! [Line No: 159]';
              Wk_errflag := -20020;

              GOTO EXIT_ROUTINE;
           END IF;
 END;

   -- *****************************************************************************
   -- PROCESS ENDDING ... !
   -- *****************************************************************************
   <<EXIT_ROUTINE>>

   -- ENDING...[0.1] CURSOR CLOSE �� Ȯ�� ó�� !
   IF Wk_errflag = 0 THEN
      Wk_errmsg  := '';                        -- ����� ���� Error Message
      Wk_errflag := 0;                         -- ����� ���� Error Code
   ELSE
      Wk_errmsg := RTRIM(e_msg) || '/>';
      RAISE UserErr;
   END IF;

EXCEPTION
  WHEN UserErr       THEN
       RAISE_APPLICATION_ERROR(Wk_errflag, Wk_errmsg);
END sp_l_pay_closing;
/
