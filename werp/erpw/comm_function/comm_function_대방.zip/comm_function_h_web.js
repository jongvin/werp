//--------------------------------------------- �о� ������ ��ȣ ���� �� logging
function f_h_web_receive_print(arg_dept, arg_sell, arg_dongho, arg_cust, arg_date, arg_amt,  arg_id, arg_remarks)   
//---------------------------------------------------------------------------
{

	var ll_receive_no, ll_from_no, ll_to_no
	var ls_temp, ll_t
alert(999)
	ls_temp = arg_date.substr(3, 1) + arg_date.substr(5, 2)
	ll_from_no = parseInt(ls_temp + '0000')
	ll_to_no   = parseInt(ls_temp + '9999')

alert(1)
	for (i=1; i<=1; i++) 
	{
alert(2)
		ll_cnt = f_selectr_q("select max(receive_no) select_1  from h_receive_print  where receive_no between  ll_from_no  and  ll_to_no ")   
		if (ll_cnt > 0)  
			ll_receive_no = parseInt(ds_selectr.NameValue(1,'select_1'))
		else
			ll_receive_no = ll_from_no	

alert(3)
		ll_receive_no++
		
alert(4)
		arg_cmd = " insert into h_receive_print " +
	   			 "   values ('" + ll_receive_no + "' , " +
	   			 " '" + arg_dept + "' , " + 
	   			 " '" + arg_sell + "' , " + 
	   			 " '" + arg_dongho + "' , " + 
	   			 " '" + arg_cust + "' , " + 
	   			 " '" + arg_date + "' , " + 
	   			 " "  + arg_amt  ", " +
	   			 " '" + sysdate + "' , " + 
	   			 " '" + arg_id + "' , " + 
	   			 " '" + arg_remarks + "' ) " 
					 
alert(arg_cmd)
		f_update_receive_print_sql(arg_cmd)
		
	}  

alert(ll_receive_no)

	return ll_receive_no

}     

//---------------------------------------------------------------------------------
function f_update_receive_print_sql(ls_sql)     //���α׷����� ���ٷ� sql������ �̿��Ͽ� update,delete,insert�Ұ����
//---------------------------------------------------------------------------------
{   
	var ll

    ds_update.DataID = "/erpw/comm_function/comm_update.jsp?arg_cmd=" + ls_sql
    ds_update.SyncLoad = true
    ll = ds_update.reset()
    alert(ll)
}
